document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Empêche le rechargement de la page

    const form = event.target;
    const formData = new FormData(form);

    // Configuration pour l'API Formspree
    fetch(form.action, {
        method: 'POST',
        body: formData,
    })
    .then(response => {
        console.log(response);
        if (response.ok) {
            alert('Votre message a été envoyé avec succès.');
            form.reset(); // Réinitialiser le formulaire
        } else {
            alert('Une erreur est survenue. Veuillez réessayer.');
        }
    })
    .catch(error => {
        console.error('Erreur:', error);
        alert('Une erreur est survenue. Veuillez réessayer.');
    });
});
